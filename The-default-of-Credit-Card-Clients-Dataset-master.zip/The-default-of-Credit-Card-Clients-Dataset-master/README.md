# The-default-of-Credit-Card-Clients-Dataset

https://medium.com/@manish.kumar_61520/the-default-of-credit-card-clients-dataset-81908562a67e
